# udroid-extra-tool-proot
[WIP] a tool to manage basic things in udroid or any proot environment
